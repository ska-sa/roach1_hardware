09/25/06

Notes on the IBIS model:
Model supports the 2.5V mode in the DDR I/O with terminator on or off.
